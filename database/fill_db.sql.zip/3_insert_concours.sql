INSERT INTO Concours (theme, descriptionConcours,dateDebut, dateFin, etat, prime, idPresident)
VALUES
('Espace','Concours sur le theme de l espace','2021-09-01','2021-02-01','evalue',100,1),
('Science fiction','Concours sur le theme de la science fiction','2021-10-01','2021-05-01','resultat',200,11),
('Nature morte','cConcours sur le theme des natures  mortes','2021-11-01','2021-08-01','en cours',300,37),
('Street Art','Concours sur le theme du street art','2021-12-01','2021-11-01','pas commence',400,56);