﻿INSERT INTO Club(nom, adresse, numTelephone, ville, departement, region)
VALUES

('nom', '1 rue des fleurs', '0601010101', 'Concarneau', 'Finistère', 'Bretagne'),
('nom', '2 rue des bouchers', '0601010102', 'Quimper', 'Finistère', 'Bretagne'),

('nom', '3 rue des oliviers', '0601010103', 'Vannes', 'Morbihan', 'Bretagne'),
('nom', '4 rue de la trinquette', '0601010104', 'Vannes', 'Morbihan', 'Bretagne'),

('nom', '5 rue des pommiers', '0601010105', 'Givet', 'Ardennes', 'Grand Est'),
('nom', '6 rue des poiriers', '0601010106', 'Sedan', 'Ardennes', 'Grand Est'),

('nom', '7 rue des stantors', '0601010107', 'Verdun', 'Meuse', 'Grand Est'),
('nom', '8 rue des albators', '0601010108', 'Étain', 'Meuse', 'Grand Est'),

('nom', '9 rue des zinzins', '0601010109', 'Les Herbiers', 'Vendée', 'Pays de la Loire'),
('nom', '10 rue des philipes', '0601010110', 'Les Landes Genusson', 'Vendée', 'Pays de la Loire'),

('nom', '11 rue des oiseaux', '0601010111', 'Le Mans', 'Sarthe', 'Pays de la Loire'),
('nom', '12 rue des potiers', '0601010112', 'Le Mans', 'Sarthe', 'Pays de la Loire'),

('nom', '13 rue de lane', '0601010113', 'Toulouse', 'Haute-Garonne', 'Occitanie'),
('nom', '14 rue des pédéstriers', '0601010114', 'Muret', 'Haute-Garonne', 'Occitanie'),

('nom', '15 rue des brababam', '0601010115', 'Viols-Le-Fort', 'Hérault', 'Occitanie'),
('nom', '16 rue des broubouboum', '0601010116', 'Viols-Le-Fort', 'Hérault', 'Occitanie');









